# weather-forecast
Weather forecast app using HTML, CSS, JS and OpenWeatherMap
